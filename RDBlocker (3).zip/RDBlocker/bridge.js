(() => {
  const CHANNEL_TOKEN = "__gx_" + Math.random().toString(36).slice(2) + Date.now().toString(36);

  function mainWorldBlocker(TOKEN) {
    if (window.__gxInstalled) return;
    window.__gxInstalled = true;
    try {
      document.documentElement.setAttribute("data-gx-active", "1");
    } catch {}

    const TWO_PART_TLDS = new Set([
      "com.vn", "net.vn", "org.vn", "edu.vn", "gov.vn", "int.vn", "ac.vn", "biz.vn", "info.vn", "name.vn", "pro.vn", "health.vn",
      "co.uk", "org.uk", "me.uk", "ac.uk", "gov.uk",
      "com.au", "net.au", "org.au", "edu.au",
      "co.jp", "ne.jp", "or.jp", "ac.jp", "go.jp",
      "co.kr", "or.kr", "go.kr",
      "com.sg", "edu.sg", "gov.sg",
      "com.tw", "org.tw", "edu.tw",
      "com.hk", "org.hk", "edu.hk",
      "co.th", "in.th", "ac.th",
      "com.my", "edu.my", "gov.my",
      "co.id", "web.id", "sch.id",
      "com.br", "org.br", "com.mx", "co.in", "org.in"
    ]);

    function getRootDomain(hostname) {
      const clean = hostname.toLowerCase().replace(/^www\./, "");
      if (!clean || /^\d+\.\d+\.\d+\.\d+$/.test(clean)) return clean;
      const parts = clean.split(".");
      if (parts.length <= 2) return clean;
      const lastTwo = parts.slice(-2).join(".");
      if (TWO_PART_TLDS.has(lastTwo) && parts.length >= 3) {
        return parts.slice(-3).join(".");
      }
      return lastTwo;
    }

    let isEnabled = true;
    let whitelist = [
      "google.com",
      "youtube.com",
      "facebook.com",
      "github.com",
      "opera.com",
      "wikipedia.org",
      "vnpay.vn",
      "momo.vn",
      "zalopay.vn"
    ];

    try {
      const cached = sessionStorage.getItem("__gx_state_cache");
      if (cached) {
        const parsed = JSON.parse(cached);
        if (typeof parsed.enabled === "boolean") isEnabled = parsed.enabled;
        if (Array.isArray(parsed.whitelist)) whitelist = parsed.whitelist;
      }
    } catch {}

    const currentHost = window.location.hostname.toLowerCase().replace(/^www\./, "");
    const currentRootDomain = getRootDomain(currentHost);

    function getHierarchyDomains() {
      const hosts = [currentHost];
      try {
        if (window.location.ancestorOrigins) {
          for (let i = 0; i < window.location.ancestorOrigins.length; i++) {
            const origin = window.location.ancestorOrigins[i];
            const h = new URL(origin).hostname.toLowerCase().replace(/^www\./, "");
            if (h && !hosts.includes(h)) hosts.push(h);
          }
        }
      } catch {}
      return hosts;
    }

    const hierarchyHosts = getHierarchyDomains();

    function isSiteBypassed() {
      if (!isEnabled) return true;
      return hierarchyHosts.some((h) => {
        const root = getRootDomain(h);
        return whitelist.some((d) => h === d || h.endsWith("." + d) || root === d);
      });
    }

    function normalizeUrl(url) {
      try {
        const u = new URL(url, window.location.href);
        u.hash = "";
        return u.href.replace(/\/+$/, "");
      } catch {
        return url || "";
      }
    }

    const nativePostMessage = window.postMessage.bind(window);

    function notifyBridge(payload) {
      try {
        nativePostMessage(Object.assign({ __gxToken: TOKEN }, payload), "*");
      } catch {}
    }

    window.addEventListener(
      "message",
      (event) => {
        if (event.source !== window || !event.data || event.data.__gxToken !== TOKEN) return;
        if (event.data.type === "GX_SYNC_STATE") {
          isEnabled = event.data.enabled;
          whitelist = event.data.whitelist;
        } else if (event.data.type === "GX_STOP_NAVIGATION") {
          try {
            window.stop();
          } catch {}
        }
      },
      true
    );

    let allowMode = "NONE";
    let allowedTargetUrl = null;
    let allowedUntil = 0;
    let lockedAnchor = null;
    let lockedHref = null;
    let lastInputTime = 0;
    let lastInputPingSent = 0;
    let lastNewTabAttemptTime = 0;

    function isSameSite(targetUrl) {
      try {
        const parsed = new URL(targetUrl, window.location.href);
        if (parsed.protocol === "blob:" || parsed.protocol === "data:") return true;
        const parsedHost = parsed.hostname.toLowerCase().replace(/^www\./, "");
        return (
          parsedHost === currentHost ||
          parsedHost.endsWith("." + currentHost) ||
          getRootDomain(parsedHost) === currentRootDomain
        );
      } catch {
        return false;
      }
    }

    function isUiPseudoLink(anchor) {
      const rawHref = (anchor.getAttribute("href") || "").trim().toLowerCase();
      return !rawHref || rawHref.startsWith("#") || rawHref.startsWith("javascript:");
    }

    function opensNewBrowsingContext(el) {
      let t = (el && el.getAttribute && el.getAttribute("target")) || "";
      if (!t) {
        const baseEl = document.querySelector("base[target]");
        if (baseEl) t = baseEl.getAttribute("target") || "";
      }
      t = t.trim();
      if (!t || t === "_self" || t === "_parent" || t === "_top") return false;
      try {
        if (document.querySelector(`iframe[name="${CSS.escape(t)}"], frame[name="${CSS.escape(t)}"]`)) {
          return false;
        }
      } catch {}
      return true;
    }

    function isTrulyVisible(el) {
      if (!el || el.nodeType !== 1) return false;
      if (typeof el.checkVisibility === "function") {
        return el.checkVisibility({ checkOpacity: true, checkVisibilityCSS: true });
      }
      const style = window.getComputedStyle(el);
      return (
        style.display !== "none" &&
        style.visibility !== "hidden" &&
        parseFloat(style.opacity) >= 0.4
      );
    }

    function markUserInputActivity(e) {
      if (!e.isTrusted) return;
      lastInputTime = Date.now();
      if (Date.now() - lastInputPingSent > 3000) {
        lastInputPingSent = Date.now();
        notifyBridge({ type: "GX_FORM_DIRTY" });
      }
    }

    window.addEventListener("input", markUserInputActivity, true);
    window.addEventListener("change", markUserInputActivity, true);

    window.addEventListener(
      "submit",
      (e) => {
        if (e.isTrusted) {
          allowMode = "ANY";
          allowedUntil = Date.now() + 6000;
          notifyBridge({ type: "GX_ALLOW_ACTION", mode: "ANY", duration: 6000 });
        }
      },
      true
    );

    window.addEventListener("beforeunload", (e) => {
      if (isSiteBypassed()) return;
      const hasRecentEdit = Date.now() - lastInputTime < 30000;
      const isUnauthorized = allowMode === "NONE" || Date.now() > allowedUntil;
      if (hasRecentEdit && isUnauthorized) {
        e.preventDefault();
        e.returnValue = "";
      }
    });

    function getElementBox(el) {
      const style = window.getComputedStyle(el);
      if (style.display === "contents" && el.firstElementChild) {
        return el.firstElementChild.getBoundingClientRect();
      }
      return el.getBoundingClientRect();
    }

    function hasMeaningfulContent(el) {
      return (
        el.innerText.trim().length > 0 ||
        el.querySelector("img, svg, i, span, picture, canvas") !== null
      );
    }

    function isRealVisibleExternalLink(anchor) {
      if (!anchor || !isTrulyVisible(anchor)) return false;
      const rect = getElementBox(anchor);
      if (rect.width === 0 || rect.height === 0) return false;
      if (rect.width >= window.innerWidth * 0.65 && rect.height >= window.innerHeight * 0.65) {
        return false;
      }
      return hasMeaningfulContent(anchor);
    }

    function findTargetControls(event) {
      const path = typeof event.composedPath === "function" ? event.composedPath() : [event.target];
      let foundAnchor = null;
      let foundButton = null;
      let isNativeControl = false;

      for (let i = 0; i < path.length; i++) {
        const node = path[i];
        if (!node || node.nodeType !== 1) continue;
        if (node === document.body || node === document.documentElement) break;

        if (node.matches && node.matches('video, [class*="player" i], [id*="player" i]')) {
          return { anchor: null, button: null, isNativeControl: false };
        }

        if (!foundAnchor && node.tagName === "A" && node.hasAttribute("href")) {
          foundAnchor = node;
        }

        if (!foundButton) {
          if (
            node.matches &&
            node.matches('button, input[type="submit"], input[type="button"], [role="button"], label, summary')
          ) {
            foundButton = node;
            isNativeControl = true;
          } else if (i < 6 && window.getComputedStyle(node).cursor === "pointer") {
            foundButton = node;
          }
        }
      }

      return { anchor: foundAnchor, button: foundButton, isNativeControl };
    }

    function isValidButtonElement(candidate, isNativeControl) {
      if (!candidate || !isTrulyVisible(candidate)) return false;
      const rect = getElementBox(candidate);
      if (rect.width === 0 || rect.height === 0) return false;
      if (rect.width >= window.innerWidth * 0.5 || rect.height >= window.innerHeight * 0.5) {
        return false;
      }
      if (!isNativeControl && !hasMeaningfulContent(candidate)) {
        return false;
      }
      return true;
    }

    function authorizeUserEvent(event, wantsNewTab = false, defaultDuration = 3500) {
      const { anchor, button, isNativeControl } = findTargetControls(event);

      if (anchor && !isUiPseudoLink(anchor)) {
        const isInternal = isSameSite(anchor.href);
        if (isInternal || isRealVisibleExternalLink(anchor)) {
          lockedAnchor = anchor;
          lockedHref = anchor.href;
          allowMode = wantsNewTab ? "NEW_TAB" : "DOMAIN";
          allowedTargetUrl = lockedHref;
          allowedUntil = Date.now() + defaultDuration;
          notifyBridge({
            type: "GX_ALLOW_ACTION",
            mode: allowMode,
            url: lockedHref,
            duration: defaultDuration
          });
          return true;
        }
      }

      if (button && isValidButtonElement(button, isNativeControl)) {
        const btnDuration = isNativeControl ? 5000 : 2500;
        allowMode = "ANY";
        allowedTargetUrl = null;
        allowedUntil = Date.now() + btnDuration;
        notifyBridge({ type: "GX_ALLOW_ACTION", mode: "ANY", duration: btnDuration });
        return true;
      }

      return false;
    }

    function isAllowedDestination(targetUrl, isNewTab = false) {
      if (isSiteBypassed()) return true;
      if (!targetUrl) return false;

      if (targetUrl.startsWith("blob:") || targetUrl.startsWith("data:")) return true;

      const isSelfClone = normalizeUrl(targetUrl) === normalizeUrl(window.location.href);

      if (isNewTab) {
        if (isSelfClone || isSameSite(targetUrl)) {
          return allowMode === "NEW_TAB" && Date.now() <= allowedUntil;
        }
        if (Date.now() > allowedUntil || allowMode === "NONE") return false;
      }

      if (!isNewTab && !isSameSite(targetUrl) && Date.now() - lastNewTabAttemptTime < 1500) {
        return false;
      }

      if (!isNewTab && !isSelfClone && isSameSite(targetUrl)) return true;

      if (Date.now() <= allowedUntil) {
        if (allowMode === "ANY" || allowMode === "NEW_TAB") return true;
        if (allowMode === "DOMAIN" && allowedTargetUrl) {
          try {
            const expectedHost = new URL(allowedTargetUrl, window.location.href).hostname;
            const actualHost = new URL(targetUrl, window.location.href).hostname;
            return (
              expectedHost === actualHost ||
              actualHost.endsWith("." + expectedHost) ||
              getRootDomain(expectedHost) === getRootDomain(actualHost)
            );
          } catch {
            return false;
          }
        }
      }
      return false;
    }

    function createFakeWindow(url) {
      lastNewTabAttemptTime = Date.now();
      notifyBridge({ type: "GX_INCREMENT_BLOCK" });
      const fakeLocation = { href: url || "about:blank", assign() {}, replace() {} };
      return new Proxy(
        {
          closed: false,
          opener: window,
          location: fakeLocation,
          document: { write() {}, writeln() {}, close() {}, open() {} },
          focus() {},
          blur() {},
          close() { this.closed = true; },
          postMessage() {}
        },
        {
          get(target, prop) {
            return prop in target ? target[prop] : () => {};
          },
          set(target, prop, value) {
            target[prop] = value;
            return true;
          }
        }
      );
    }

    ["pointerover", "pointerdown", "mousedown", "click", "auxclick", "touchstart"].forEach((eventType) => {
      window.addEventListener(
        eventType,
        (e) => {
          if (!e.isTrusted || isSiteBypassed()) return;

          if (eventType === "pointerover" || eventType === "pointerdown" || eventType === "touchstart") {
            const { anchor } = findTargetControls(e);
            if (anchor && !isUiPseudoLink(anchor) && lockedAnchor !== anchor) {
              lockedAnchor = anchor;
              lockedHref = anchor.href;
            }
          }

          if (eventType === "pointerover") return;

          if (e.button === 2) {
            authorizeUserEvent(e, true, 8000);
            return;
          }

          const wantsNewTab = e.button === 1 || e.ctrlKey || e.metaKey || e.shiftKey;
          const authorized = authorizeUserEvent(e, wantsNewTab, 3500);

          if (!authorized) {
            lockedAnchor = null;
            lockedHref = null;
            allowMode = "NONE";
            allowedTargetUrl = null;
            allowedUntil = 0;
          }
        },
        true
      );
    });

    window.addEventListener(
      "contextmenu",
      (e) => {
        if (!e.isTrusted || isSiteBypassed()) return;
        authorizeUserEvent(e, true, 8000);
      },
      true
    );

    window.addEventListener(
      "keydown",
      (e) => {
        if (!e.isTrusted || isSiteBypassed()) return;
        if (e.key === "Enter" || e.key === " ") {
          const wantsNewTab = e.ctrlKey || e.metaKey || e.shiftKey;
          authorizeUserEvent(e, wantsNewTab, 3500);
        }
      },
      true
    );

    function handleAnchorActivation(e) {
      if (isSiteBypassed()) return;

      const { anchor } = findTargetControls(e);
      if (!anchor || isUiPseudoLink(anchor)) return;

      const isSelfClone = normalizeUrl(anchor.href) === normalizeUrl(window.location.href);
      const wantsNewTab = e.button === 1 || e.ctrlKey || e.metaKey || e.shiftKey;
      const forcesNewTab = opensNewBrowsingContext(anchor);

      if (isSelfClone && (forcesNewTab || wantsNewTab)) {
        e.preventDefault();
        lastNewTabAttemptTime = Date.now();
        notifyBridge({ type: "GX_INCREMENT_BLOCK" });
        return;
      }

      if (isSameSite(anchor.href)) {
        if (lockedAnchor === anchor && lockedHref && anchor.href !== lockedHref) {
          anchor.href = lockedHref;
        }
        if (!wantsNewTab && forcesNewTab) {
          anchor.setAttribute("target", "_self");
        }
        return;
      }

      if (!isRealVisibleExternalLink(anchor)) {
        e.preventDefault();
        notifyBridge({ type: "GX_INCREMENT_BLOCK" });
        return;
      }

      if (lockedAnchor === anchor && lockedHref && anchor.href !== lockedHref) {
        anchor.href = lockedHref;
      }
    }

    document.addEventListener("click", handleAnchorActivation, true);
    document.addEventListener("auxclick", handleAnchorActivation, true);

    function patchWindowOpen(win) {
      if (!win || win.__gxOpenLocked) return;
      try {
        const nativeOpen = win.open;
        Object.defineProperty(win, "open", {
          configurable: false,
          writable: false,
          value: function (url) {
            if (!isAllowedDestination(url, true)) {
              return createFakeWindow(url);
            }
            return nativeOpen.apply(this, arguments);
          }
        });
        Object.defineProperty(win, "__gxOpenLocked", { value: true });
      } catch {}
    }

    function patchFrameTree(node) {
      if (!node || node.nodeType !== 1) return;
      if (node.tagName === "IFRAME" || node.tagName === "FRAME") {
        try {
          if (node.contentWindow) patchWindowOpen(node.contentWindow);
        } catch {}
      }
      if (node.querySelectorAll) {
        node.querySelectorAll("iframe, frame").forEach((f) => {
          try {
            if (f.contentWindow) patchWindowOpen(f.contentWindow);
          } catch {}
        });
      }
    }

    patchWindowOpen(window);

    [
      [Node.prototype, "appendChild"],
      [Node.prototype, "insertBefore"],
      [Element.prototype, "append"],
      [Element.prototype, "prepend"],
      [Element.prototype, "insertAdjacentElement"]
    ].forEach(([proto, methodName]) => {
      const orig = proto[methodName];
      if (typeof orig === "function") {
        proto[methodName] = function (...args) {
          const res = orig.apply(this, args);
          for (const arg of args) {
            if (arg && arg.nodeType === 1) patchFrameTree(arg);
          }
          return res;
        };
      }
    });

    const nativeAnchorClick = HTMLAnchorElement.prototype.click;
    Object.defineProperty(HTMLAnchorElement.prototype, "click", {
      configurable: false,
      writable: false,
      value: function () {
        const opensNewTab = opensNewBrowsingContext(this);
        const isDownload = this.hasAttribute("download") && allowMode === "ANY" && Date.now() <= allowedUntil;
        if (!isSiteBypassed() && !isDownload && !isAllowedDestination(this.href, opensNewTab)) {
          lastNewTabAttemptTime = Date.now();
          notifyBridge({ type: "GX_INCREMENT_BLOCK" });
          return;
        }
        return nativeAnchorClick.apply(this, arguments);
      }
    });

    const nativeFormSubmit = HTMLFormElement.prototype.submit;
    Object.defineProperty(HTMLFormElement.prototype, "submit", {
      configurable: false,
      writable: false,
      value: function () {
        if (!isSiteBypassed() && opensNewBrowsingContext(this) && !isAllowedDestination(this.action, true)) {
          lastNewTabAttemptTime = Date.now();
          notifyBridge({ type: "GX_INCREMENT_BLOCK" });
          return;
        }
        return nativeFormSubmit.apply(this, arguments);
      }
    });

    try {
      if (window.navigation && typeof window.navigation.addEventListener === "function") {
        window.navigation.addEventListener("navigate", (e) => {
          if (isSiteBypassed() || e.navigationType === "reload" || e.hashChange || e.downloadRequest) {
            return;
          }
          const dest = e.destination && e.destination.url;
          if (!dest || isSameSite(dest)) return;

          const hasRecentInput = Date.now() - lastInputTime < 20000;
          if (hasRecentInput && allowMode === "ANY" && Date.now() <= allowedUntil) {
            return;
          }

          if (!isAllowedDestination(dest, false) && e.cancelable) {
            e.preventDefault();
            notifyBridge({ type: "GX_INCREMENT_BLOCK" });
          }
        });
      }
    } catch {}

    const nativeDocWrite = Document.prototype.write;
    Document.prototype.write = function () {
      if (!isSiteBypassed() && this.readyState === "complete") return;
      return nativeDocWrite.apply(this, arguments);
    };

    const observer = new MutationObserver(() => {
      if (isSiteBypassed()) return;
      document.querySelectorAll('meta[http-equiv="refresh" i]').forEach((m) => m.remove());
      document.querySelectorAll("base[target]").forEach((b) => {
        const t = (b.getAttribute("target") || "").trim();
        if (t && t !== "_self" && t !== "_parent" && t !== "_top") {
          b.removeAttribute("target");
        }
      });
      for (let i = 0; i < window.frames.length; i++) {
        patchWindowOpen(window.frames[i]);
      }
    });
    if (document.documentElement) {
      observer.observe(document.documentElement, { childList: true, subtree: true });
    }
  }

  // Tiêm trực tiếp vào Main World ngay tại 0ms (kèm nonce để vượt CSP trên iOS)
  function injectMainWorld() {
    const parent = document.head || document.documentElement;
    if (!parent) return;

    const inlineScript = document.createElement("script");
    const existingNonceEl = document.querySelector("script[nonce]");
    if (existingNonceEl) {
      const nonceVal = existingNonceEl.nonce || existingNonceEl.getAttribute("nonce");
      if (nonceVal) inlineScript.setAttribute("nonce", nonceVal);
    }
    inlineScript.textContent = `(${mainWorldBlocker.toString()})(${JSON.stringify(CHANNEL_TOKEN)});`;
    parent.appendChild(inlineScript);
    inlineScript.remove();

    // Dự phòng nếu trang có CSP quá chặt chặn script nội tuyến
    if (document.documentElement && document.documentElement.getAttribute("data-gx-active") !== "1") {
      try {
        const extScript = document.createElement("script");
        extScript.src = chrome.runtime.getURL("blocker.js");
        extScript.setAttribute("data-gx-token", CHANNEL_TOKEN);
        extScript.onload = () => extScript.remove();
        parent.appendChild(extScript);
      } catch {}
    }
  }

  injectMainWorld();

  function pushStateToPage() {
    chrome.storage.local.get(["enabled", "whitelist"], (res) => {
      const state = {
        __gxToken: CHANNEL_TOKEN,
        type: "GX_SYNC_STATE",
        enabled: typeof res.enabled === "boolean" ? res.enabled : true,
        whitelist: Array.isArray(res.whitelist) ? res.whitelist : []
      };
      try {
        sessionStorage.setItem("__gx_state_cache", JSON.stringify(state));
      } catch {}
      window.postMessage(state, "*");
    });
  }

  pushStateToPage();

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && (changes.enabled || changes.whitelist)) {
      pushStateToPage();
    }
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === "GX_STOP_NAVIGATION") {
      window.postMessage({ __gxToken: CHANNEL_TOKEN, type: "GX_STOP_NAVIGATION" }, "*");
    }
  });

  window.addEventListener(
    "message",
    (event) => {
      if (event.source !== window || !event.data || event.data.__gxToken !== CHANNEL_TOKEN) return;
      const { type, mode, url, duration } = event.data;
      if (type === "GX_ALLOW_ACTION" || type === "GX_FORM_DIRTY" || type === "GX_INCREMENT_BLOCK") {
        try {
          chrome.runtime.sendMessage({ type, mode, url, duration });
        } catch {}
      }
    },
    true
  );
})();