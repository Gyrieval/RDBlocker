const DEFAULT_WHITELIST = [
  "google.com",
  "youtube.com",
  "facebook.com",
  "github.com",
  "opera.com",
  "wikipedia.org",
  "vnpay.vn",
  "momo.vn",
  "zalopay.vn"
];

const TWO_PART_TLDS = new Set([
  "com.vn", "net.vn", "org.vn", "edu.vn", "gov.vn", "int.vn", "ac.vn", "biz.vn", "info.vn", "name.vn", "pro.vn", "health.vn",
  "co.uk", "org.uk", "me.uk", "ac.uk", "gov.uk",
  "com.au", "net.au", "org.au", "edu.au",
  "co.jp", "ne.jp", "or.jp", "ac.jp", "go.jp",
  "co.kr", "or.kr", "go.kr",
  "com.sg", "edu.sg", "gov.sg",
  "com.tw", "org.tw", "edu.tw",
  "com.hk", "org.hk", "edu.hk",
  "co.th", "in.th", "ac.th",
  "com.my", "edu.my", "gov.my",
  "co.id", "web.id", "sch.id",
  "com.br", "org.br", "com.mx", "co.in", "org.in"
]);

let appState = {
  enabled: true,
  whitelist: [...DEFAULT_WHITELIST],
  blockedCount: 0
};

// Hàm hỗ trợ tương thích chéo giữa Manifest V2 (Orion iOS) và Manifest V3
function isInternalBrowserUrl(url) {
  if (!url || url === "about:blank") return true;
  return (
    url.startsWith("opera://") ||
    url.startsWith("chrome://") ||
    url.startsWith("orion://") ||
    url.startsWith("safari-web-extension://") ||
    url.startsWith("moz-extension://")
  );
}

function getTabAsync(tabId) {
  return new Promise((resolve) => {
    try {
      chrome.tabs.get(tabId, (tab) => {
        if (chrome.runtime.lastError) {
          resolve(null);
        } else {
          resolve(tab || null);
        }
      });
    } catch {
      resolve(null);
    }
  });
}

function safeTabsUpdate(tabId, updateProperties) {
  try {
    const res = chrome.tabs.update(tabId, updateProperties, () => {
      void chrome.runtime.lastError;
    });
    if (res && typeof res.catch === "function") res.catch(() => {});
  } catch {}
}

function safeTabsRemove(tabId) {
  try {
    const res = chrome.tabs.remove(tabId, () => {
      void chrome.runtime.lastError;
    });
    if (res && typeof res.catch === "function") res.catch(() => {});
  } catch {}
}

function safeTabsSendMessage(tabId, message) {
  try {
    const res = chrome.tabs.sendMessage(tabId, message, () => {
      void chrome.runtime.lastError;
    });
    if (res && typeof res.catch === "function") res.catch(() => {});
  } catch {}
}

function safeTabsGoBackOrUpdate(tabId, fallbackUrl) {
  try {
    if (chrome.tabs.goBack) {
      const res = chrome.tabs.goBack(tabId, () => {
        if (chrome.runtime.lastError) {
          safeTabsUpdate(tabId, { url: fallbackUrl });
        }
      });
      if (res && typeof res.catch === "function") {
        res.catch(() => safeTabsUpdate(tabId, { url: fallbackUrl }));
      }
      return;
    }
  } catch {}
  safeTabsUpdate(tabId, { url: fallbackUrl });
}

chrome.storage.local.get(["enabled", "whitelist", "blockedCount"], (res) => {
  if (typeof res.enabled === "boolean") appState.enabled = res.enabled;
  if (Array.isArray(res.whitelist)) {
    appState.whitelist = res.whitelist;
  } else {
    chrome.storage.local.set({ whitelist: DEFAULT_WHITELIST });
  }
  if (typeof res.blockedCount === "number") appState.blockedCount = res.blockedCount;
  updateBadge();
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes.enabled) appState.enabled = changes.enabled.newValue;
  if (changes.whitelist) appState.whitelist = changes.whitelist.newValue || [];
  if (changes.blockedCount) appState.blockedCount = changes.blockedCount.newValue || 0;
  updateBadge();
});

const actionApi = chrome.action || chrome.browserAction;

function updateBadge() {
  if (!actionApi) return;
  try {
    if (!appState.enabled) {
      if (actionApi.setBadgeText) actionApi.setBadgeText({ text: "OFF" });
      if (actionApi.setBadgeBackgroundColor) actionApi.setBadgeBackgroundColor({ color: "#6b7280" });
    } else {
      const text = appState.blockedCount > 0 ? String(appState.blockedCount) : "";
      if (actionApi.setBadgeText) actionApi.setBadgeText({ text });
      if (actionApi.setBadgeBackgroundColor) actionApi.setBadgeBackgroundColor({ color: "#fa1e4e" });
    }
  } catch {}
}

function incrementBlockedCount() {
  appState.blockedCount += 1;
  chrome.storage.local.set({ blockedCount: appState.blockedCount });
  updateBadge();
}

function getHostname(url) {
  try {
    return new URL(url).hostname.toLowerCase().replace(/^www\./, "");
  } catch {
    return "";
  }
}

function getRootDomain(hostname) {
  const clean = hostname.toLowerCase().replace(/^www\./, "");
  if (!clean || /^\d+\.\d+\.\d+\.\d+$/.test(clean)) return clean;
  const parts = clean.split(".");
  if (parts.length <= 2) return clean;
  const lastTwo = parts.slice(-2).join(".");
  if (TWO_PART_TLDS.has(lastTwo) && parts.length >= 3) {
    return parts.slice(-3).join(".");
  }
  return lastTwo;
}

function normalizeUrl(url) {
  try {
    const u = new URL(url);
    u.hash = "";
    return u.href.replace(/\/+$/, "");
  } catch {
    return url || "";
  }
}

function isWhitelisted(url) {
  const host = getHostname(url);
  if (!host) return true;
  const root = getRootDomain(host);
  return appState.whitelist.some((d) => host === d || host.endsWith("." + d) || root === d);
}

function isSameDomain(urlA, urlB) {
  const hostA = getHostname(urlA);
  const hostB = getHostname(urlB);
  if (!hostA || !hostB) return false;
  return (
    hostA === hostB ||
    hostA.endsWith("." + hostB) ||
    hostB.endsWith("." + hostA) ||
    getRootDomain(hostA) === getRootDomain(hostB)
  );
}

const allowedActionsByTab = new Map();
const dirtyFormTabs = new Map();
const pendingTabs = new Map();
const verificationTimers = new Map();
const revertTracker = new Map();
const tabCommittedUrls = new Map();
const blockedNavigations = new Map();
let tabSafeUrls = new Map();

function saveSafeUrls() {
  if (!chrome.storage || !chrome.storage.session) return;
  try {
    const obj = Object.fromEntries(tabSafeUrls);
    const res = chrome.storage.session.set({ tabSafeUrls: obj }, () => {
      void chrome.runtime.lastError;
    });
    if (res && typeof res.catch === "function") res.catch(() => {});
  } catch {}
}

const sessionReady = new Promise((resolve) => {
  const initTabs = () => {
    chrome.tabs.query({}, (tabs) => {
      if (Array.isArray(tabs)) {
        for (const tab of tabs) {
          if (tab.id && tab.url && tab.url.startsWith("http")) {
            tabCommittedUrls.set(tab.id, tab.url);
            if (!tabSafeUrls.has(tab.id)) {
              tabSafeUrls.set(tab.id, tab.url);
            }
          }
        }
      }
      saveSafeUrls();
      resolve();
    });
  };

  if (chrome.storage && chrome.storage.session) {
    try {
      chrome.storage.session.get(["tabSafeUrls"], (res) => {
        if (!chrome.runtime.lastError && res && res.tabSafeUrls) {
          tabSafeUrls = new Map(Object.entries(res.tabSafeUrls).map(([k, v]) => [Number(k), v]));
        }
        initTabs();
      });
    } catch {
      initTabs();
    }
  } else {
    initTabs();
  }
});

function markNavigationBlocked(tabId, badUrl) {
  blockedNavigations.set(tabId, {
    url: normalizeUrl(badUrl),
    expiresAt: Date.now() + 5000
  });
}

function isNavigationRecentlyBlocked(tabId, url) {
  const record = blockedNavigations.get(tabId);
  if (!record) return false;
  if (Date.now() > record.expiresAt) {
    blockedNavigations.delete(tabId);
    return false;
  }
  return record.url === normalizeUrl(url);
}

chrome.runtime.onMessage.addListener((msg, sender) => {
  if (!msg) return;

  if (msg.type === "GX_ALLOW_ACTION" && sender.tab) {
    const duration = msg.duration || (msg.mode === "ANY" ? 5000 : 3500);
    allowedActionsByTab.set(sender.tab.id, {
      mode: msg.mode, // "DOMAIN" | "ANY" | "NEW_TAB"
      host: msg.url ? getHostname(msg.url) : "",
      rootDomain: msg.url ? getRootDomain(getHostname(msg.url)) : "",
      targetUrl: msg.url ? normalizeUrl(msg.url) : "",
      allowSingleRedirect: msg.mode === "DOMAIN",
      expiresAt: Date.now() + duration
    });
  } else if (msg.type === "GX_FORM_DIRTY" && sender.tab) {
    dirtyFormTabs.set(sender.tab.id, Date.now());
  } else if (msg.type === "GX_INCREMENT_BLOCK") {
    incrementBlockedCount();
  }
});

function hasActiveFormInput(tabId) {
  const lastInput = dirtyFormTabs.get(tabId);
  if (!lastInput) return false;
  if (Date.now() - lastInput > 20000) {
    dirtyFormTabs.delete(tabId);
    return false;
  }
  return true;
}

function isNavigationAuthorized(sourceTabId, targetUrl, isNewTab = false, isServerRedirect = false) {
  const record = allowedActionsByTab.get(sourceTabId);
  if (!record || Date.now() > record.expiresAt) return false;

  if (isNewTab) {
    if (record.mode === "NEW_TAB") {
      if (!record.targetUrl) return true;
      const targetHost = getHostname(targetUrl);
      return (
        normalizeUrl(targetUrl) === record.targetUrl ||
        Boolean(
          targetHost &&
          record.rootDomain &&
          getRootDomain(targetHost) === record.rootDomain
        )
      );
    }
    if (record.mode === "ANY") return true;
    const targetHost = getHostname(targetUrl);
    return Boolean(
      targetHost &&
      record.rootDomain &&
      getRootDomain(targetHost) === record.rootDomain
    );
  }

  if (isServerRedirect && record.allowSingleRedirect) {
    record.allowSingleRedirect = false;
    return true;
  }

  if (record.mode === "ANY" || record.mode === "NEW_TAB") return true;
  const targetHost = getHostname(targetUrl);
  return Boolean(
    targetHost &&
    record.rootDomain &&
    getRootDomain(targetHost) === record.rootDomain
  );
}

async function focusSourceTabAndWindow(sourceTabId) {
  if (!sourceTabId) return;
  const sourceTab = await getTabAsync(sourceTabId);
  if (sourceTab) {
    if (chrome.windows && chrome.windows.update && typeof sourceTab.windowId === "number") {
      try {
        const res = chrome.windows.update(sourceTab.windowId, { focused: true }, () => {
          void chrome.runtime.lastError;
        });
        if (res && typeof res.catch === "function") res.catch(() => {});
      } catch {}
    }
    safeTabsUpdate(sourceTabId, { active: true });
  }
}

function killTabSilently(badTabId, sourceTabId) {
  const existingTimer = verificationTimers.get(badTabId);
  if (existingTimer) {
    clearTimeout(existingTimer);
    verificationTimers.delete(badTabId);
  }

  if (!pendingTabs.has(badTabId)) return;
  pendingTabs.delete(badTabId);

  focusSourceTabAndWindow(sourceTabId);
  safeTabsRemove(badTabId);
  incrementBlockedCount();
}

function verifyAndBlockNewTab(badTabId, sourceTabId, targetUrl) {
  const pendingInfo = pendingTabs.get(badTabId);
  if (pendingInfo && targetUrl && targetUrl !== "about:blank") {
    pendingInfo.latestUrl = targetUrl;
  }

  if (isNavigationAuthorized(sourceTabId, targetUrl, true, false)) {
    const existingTimer = verificationTimers.get(badTabId);
    if (existingTimer) {
      clearTimeout(existingTimer);
      verificationTimers.delete(badTabId);
    }
    pendingTabs.delete(badTabId);
    allowedActionsByTab.delete(sourceTabId);
    tabSafeUrls.set(badTabId, targetUrl);
    saveSafeUrls();
    return;
  }

  focusSourceTabAndWindow(sourceTabId);

  if (verificationTimers.has(badTabId)) return;

  const timerId = setTimeout(() => {
    verificationTimers.delete(badTabId);
    const currentInfo = pendingTabs.get(badTabId);
    if (!currentInfo) return;

    const finalUrl = currentInfo.latestUrl || targetUrl;
    if (!isNavigationAuthorized(sourceTabId, finalUrl, true, false)) {
      killTabSilently(badTabId, sourceTabId);
    } else {
      pendingTabs.delete(badTabId);
      allowedActionsByTab.delete(sourceTabId);
      tabSafeUrls.set(badTabId, finalUrl);
      saveSafeUrls();
      safeTabsUpdate(badTabId, { active: true });
    }
  }, 160);

  verificationTimers.set(badTabId, timerId);
}

function safeRevertTab(tabId, safeUrl, badUrl) {
  const now = Date.now();
  const tracker = revertTracker.get(tabId) || { count: 0, firstTime: now };

  if (now - tracker.firstTime > 4000) {
    tracker.count = 0;
    tracker.firstTime = now;
  }

  tracker.count += 1;
  revertTracker.set(tabId, tracker);

  if (tracker.count > 2) return;

  if (badUrl) {
    markNavigationBlocked(tabId, badUrl);
  }

  incrementBlockedCount();
  const committedUrl = tabCommittedUrls.get(tabId) || safeUrl;

  if (normalizeUrl(committedUrl) === normalizeUrl(safeUrl)) {
    safeTabsSendMessage(tabId, { type: "GX_STOP_NAVIGATION" });
  } else {
    safeTabsGoBackOrUpdate(tabId, safeUrl);
  }
}

// 1. Bắt mọi tab hoặc cửa sổ popup mới sinh ra
if (chrome.webNavigation && chrome.webNavigation.onCreatedNavigationTarget) {
  chrome.webNavigation.onCreatedNavigationTarget.addListener(async (details) => {
    await sessionReady;
    if (!appState.enabled) return;

    const sourceTab = await getTabAsync(details.sourceTabId);
    if (!sourceTab || !sourceTab.url || isWhitelisted(sourceTab.url)) return;

    pendingTabs.set(details.tabId, {
      sourceTabId: details.sourceTabId,
      sourceUrl: sourceTab.url,
      latestUrl: details.url || ""
    });

    if (details.url && !isInternalBrowserUrl(details.url)) {
      verifyAndBlockNewTab(details.tabId, details.sourceTabId, details.url);
    }
  });
}

// 2. Chặn chuyển hướng trước khi tải nội dung
if (chrome.webNavigation && chrome.webNavigation.onBeforeNavigate) {
  chrome.webNavigation.onBeforeNavigate.addListener(async (details) => {
    if (details.frameId !== 0) return;
    await sessionReady;

    const url = details.url;
    if (isInternalBrowserUrl(url)) return;

    if (!appState.enabled) {
      tabSafeUrls.set(details.tabId, url);
      saveSafeUrls();
      return;
    }

    if (pendingTabs.has(details.tabId)) {
      const info = pendingTabs.get(details.tabId);
      verifyAndBlockNewTab(details.tabId, info.sourceTabId, url);
      return;
    }

    const currentSafeUrl = tabSafeUrls.get(details.tabId);
    const isManualNavigation =
      (details.transitionQualifiers && details.transitionQualifiers.includes("from_address_bar")) ||
      ["typed", "auto_bookmark", "generated", "reload"].includes(details.transitionType);

    if (isManualNavigation || isWhitelisted(url)) {
      blockedNavigations.delete(details.tabId);
      dirtyFormTabs.delete(details.tabId);
      tabSafeUrls.set(details.tabId, url);
      saveSafeUrls();
      return;
    }

    if (
      currentSafeUrl &&
      normalizeUrl(currentSafeUrl) !== normalizeUrl(url) &&
      !isWhitelisted(currentSafeUrl) &&
      !isSameDomain(currentSafeUrl, url)
    ) {
      const isServerRedirect =
        details.transitionQualifiers && details.transitionQualifiers.includes("server_redirect");

      if (
        hasActiveFormInput(details.tabId) ||
        isNavigationAuthorized(details.tabId, url, false, Boolean(isServerRedirect))
      ) {
        blockedNavigations.delete(details.tabId);
        dirtyFormTabs.delete(details.tabId);
        allowedActionsByTab.delete(details.tabId);
        tabSafeUrls.set(details.tabId, url);
        saveSafeUrls();
        return;
      }

      setTimeout(() => {
        if (
          hasActiveFormInput(details.tabId) ||
          isNavigationAuthorized(details.tabId, url, false, true)
        ) {
          blockedNavigations.delete(details.tabId);
          dirtyFormTabs.delete(details.tabId);
          allowedActionsByTab.delete(details.tabId);
          tabSafeUrls.set(details.tabId, url);
          saveSafeUrls();
          return;
        }
        safeRevertTab(details.tabId, currentSafeUrl, url);
      }, 160);
    }
  });
}

// 3. Kéo lùi ngay lập tức nếu trang quảng cáo đã lọt qua do mạng trễ
if (chrome.webNavigation && chrome.webNavigation.onCommitted) {
  chrome.webNavigation.onCommitted.addListener(async (details) => {
    if (details.frameId !== 0) return;
    await sessionReady;

    const url = details.url;
    if (!url || !url.startsWith("http")) return;

    if (isNavigationRecentlyBlocked(details.tabId, url)) {
      const safeUrl = tabSafeUrls.get(details.tabId);
      if (safeUrl && normalizeUrl(safeUrl) !== normalizeUrl(url)) {
        safeTabsGoBackOrUpdate(details.tabId, safeUrl);
      }
      return;
    }

    tabCommittedUrls.set(details.tabId, url);
  });
}

// 4. Lưu lại URL an toàn khi trang tải xong hoặc đổi URL trên web SPA
async function recordSafeNavigation(details) {
  if (details.frameId !== 0) return;
  await sessionReady;

  const url = details.url;
  if (!url || !url.startsWith("http")) return;

  if (isNavigationRecentlyBlocked(details.tabId, url)) {
    const safeUrl = tabSafeUrls.get(details.tabId);
    if (safeUrl && normalizeUrl(safeUrl) !== normalizeUrl(url)) {
      safeTabsGoBackOrUpdate(details.tabId, safeUrl);
    }
    return;
  }

  pendingTabs.delete(details.tabId);
  allowedActionsByTab.delete(details.tabId);
  tabCommittedUrls.set(details.tabId, url);
  tabSafeUrls.set(details.tabId, url);
  saveSafeUrls();
}

if (chrome.webNavigation) {
  if (chrome.webNavigation.onCompleted) {
    chrome.webNavigation.onCompleted.addListener(recordSafeNavigation);
  }
  if (chrome.webNavigation.onHistoryStateUpdated) {
    chrome.webNavigation.onHistoryStateUpdated.addListener(recordSafeNavigation);
  }
}

// 5. Dự phòng cho tab mở dạng about:blank rồi nạp URL trễ
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  await sessionReady;
  if (!appState.enabled) return;

  const info = pendingTabs.get(tabId);
  if (!info) return;

  const targetUrl = changeInfo.url || (tab && (tab.pendingUrl || tab.url));
  if (!targetUrl || isInternalBrowserUrl(targetUrl)) return;

  verifyAndBlockNewTab(tabId, info.sourceTabId, targetUrl);
});

chrome.tabs.onRemoved.addListener(async (tabId) => {
  await sessionReady;
  const existingTimer = verificationTimers.get(tabId);
  if (existingTimer) {
    clearTimeout(existingTimer);
    verificationTimers.delete(tabId);
  }
  pendingTabs.delete(tabId);
  allowedActionsByTab.delete(tabId);
  dirtyFormTabs.delete(tabId);
  revertTracker.delete(tabId);
  blockedNavigations.delete(tabId);
  tabCommittedUrls.delete(tabId);
  tabSafeUrls.delete(tabId);
  saveSafeUrls();
});