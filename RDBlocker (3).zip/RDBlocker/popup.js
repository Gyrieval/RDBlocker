document.addEventListener("DOMContentLoaded", async () => {
  const globalToggle = document.getElementById("globalToggle");
  const siteToggle = document.getElementById("siteToggle");
  const siteRow = document.getElementById("siteRow");
  const currentDomainEl = document.getElementById("currentDomain");
  const statusBadge = document.getElementById("statusBadge");
  const blockedCountEl = document.getElementById("blockedCount");
  const resetBtn = document.getElementById("resetBtn");

  let activeHost = "";
  let activeTabId = null;

  // Lấy tên miền của tab đang mở
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab && tab.url && tab.url.startsWith("http")) {
    activeTabId = tab.id;
    activeHost = new URL(tab.url).hostname.toLowerCase().replace(/^www\./, "");
    currentDomainEl.textContent = activeHost;
  } else {
    siteRow.style.display = "none";
  }

  // Nạp trạng thái hiện tại
  chrome.storage.local.get(["enabled", "whitelist", "blockedCount"], (res) => {
    const isEnabled = typeof res.enabled === "boolean" ? res.enabled : true;
    const whitelist = Array.isArray(res.whitelist) ? res.whitelist : [];
    const count = typeof res.blockedCount === "number" ? res.blockedCount : 0;

    globalToggle.checked = isEnabled;
    blockedCountEl.textContent = count;
    updateUIState(isEnabled);

    if (activeHost) {
      const isWhitelisted = whitelist.some(
        (d) => activeHost === d || activeHost.endsWith("." + d)
      );
      siteToggle.checked = !isWhitelisted;
    }
  });

  function updateUIState(isEnabled) {
    statusBadge.textContent = isEnabled ? "Đang bật" : "Đã tắt";
    statusBadge.style.color = isEnabled ? "#fa1e4e" : "#9ca3af";
    siteToggle.disabled = !isEnabled;
  }

  // 1. Gạt công tắc bật/tắt toàn bộ extension
  globalToggle.addEventListener("change", () => {
    const isEnabled = globalToggle.checked;
    chrome.storage.local.set({ enabled: isEnabled });
    updateUIState(isEnabled);
  });

  // 2. Gạt công tắc bật/tắt riêng cho trang web đang mở
  siteToggle.addEventListener("change", () => {
    if (!activeHost) return;
    chrome.storage.local.get(["whitelist"], (res) => {
      let whitelist = Array.isArray(res.whitelist) ? res.whitelist : [];

      if (siteToggle.checked) {
        // Bật chặn -> Xóa khỏi Whitelist
        whitelist = whitelist.filter(
          (d) => activeHost !== d && !activeHost.endsWith("." + d)
        );
      } else {
        // Tắt chặn -> Thêm vào Whitelist
        if (!whitelist.includes(activeHost)) {
          whitelist.push(activeHost);
        }
      }

      chrome.storage.local.set({ whitelist }, () => {
        if (activeTabId) {
          chrome.tabs.reload(activeTabId);
        }
      });
    });
  });

  // 3. Đặt lại bộ đếm
  resetBtn.addEventListener("click", () => {
    chrome.storage.local.set({ blockedCount: 0 });
    blockedCountEl.textContent = "0";
  });
});